extern int linenum;
extern char *in_fp;

